# Geschwindigkeitsmessung

Dieses Projekt ist die Challenge von comsysto für die Umsetzung eines Mini-Frontends.

# Code

Der Code findet sich, wie standardmäßig immer, in /src/app.
Als Framework für das UI habe zur Einfachheit Bootstrap genutzt. 

# Tests

Die Unit-Tests sind für Jasmine ausgelegt und befinden sich alle in 
app.component.spec.ts, damit alles an einem Ort liegt (die app ist ja nicht so riesig).
